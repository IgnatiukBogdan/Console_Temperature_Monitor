﻿
namespace ConsoleTemperatureMonitor
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelGPUModel = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.chartGPUActivity = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBoxGPU = new System.Windows.Forms.RichTextBox();
            this.labelGPUActivity = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.comboBoxActivityMode = new System.Windows.Forms.ComboBox();
            this.labelGPUUsage = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGPUActivity)).BeginInit();
            this.SuspendLayout();
            // 
            // labelGPUModel
            // 
            this.labelGPUModel.AutoSize = true;
            this.labelGPUModel.Location = new System.Drawing.Point(15, 37);
            this.labelGPUModel.Name = "labelGPUModel";
            this.labelGPUModel.Size = new System.Drawing.Size(81, 13);
            this.labelGPUModel.TabIndex = 1;
            this.labelGPUModel.Text = "labelGPUModel";
            // 
            // chartGPUActivity
            // 
            chartArea8.Name = "ChartArea1";
            this.chartGPUActivity.ChartAreas.Add(chartArea8);
            legend8.Name = "Legend1";
            this.chartGPUActivity.Legends.Add(legend8);
            this.chartGPUActivity.Location = new System.Drawing.Point(242, 1);
            this.chartGPUActivity.Name = "chartGPUActivity";
            series8.ChartArea = "ChartArea1";
            series8.Legend = "Legend1";
            series8.Name = "Series1";
            this.chartGPUActivity.Series.Add(series8);
            this.chartGPUActivity.Size = new System.Drawing.Size(509, 349);
            this.chartGPUActivity.TabIndex = 2;
            this.chartGPUActivity.Text = "chart1";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(15, 98);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(189, 17);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "Отображать поверх других окон";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(210, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Вкл";
            // 
            // richTextBoxGPU
            // 
            this.richTextBoxGPU.Location = new System.Drawing.Point(15, 66);
            this.richTextBoxGPU.Name = "richTextBoxGPU";
            this.richTextBoxGPU.Size = new System.Drawing.Size(198, 26);
            this.richTextBoxGPU.TabIndex = 5;
            this.richTextBoxGPU.Text = "";
            // 
            // labelGPUActivity
            // 
            this.labelGPUActivity.AutoSize = true;
            this.labelGPUActivity.Location = new System.Drawing.Point(18, 129);
            this.labelGPUActivity.Name = "labelGPUActivity";
            this.labelGPUActivity.Size = new System.Drawing.Size(67, 13);
            this.labelGPUActivity.TabIndex = 6;
            this.labelGPUActivity.Text = "GPU Activity";
            // 
            // comboBoxActivityMode
            // 
            this.comboBoxActivityMode.FormattingEnabled = true;
            this.comboBoxActivityMode.Location = new System.Drawing.Point(18, 176);
            this.comboBoxActivityMode.Name = "comboBoxActivityMode";
            this.comboBoxActivityMode.Size = new System.Drawing.Size(100, 21);
            this.comboBoxActivityMode.TabIndex = 7;
            this.comboBoxActivityMode.SelectedIndexChanged += new System.EventHandler(this.comboBoxActivityMode_SelectedIndexChanged);
            // 
            // labelGPUUsage
            // 
            this.labelGPUUsage.AutoSize = true;
            this.labelGPUUsage.Location = new System.Drawing.Point(18, 151);
            this.labelGPUUsage.Name = "labelGPUUsage";
            this.labelGPUUsage.Size = new System.Drawing.Size(64, 13);
            this.labelGPUUsage.TabIndex = 8;
            this.labelGPUUsage.Text = "GPU Usage";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 341);
            this.Controls.Add(this.labelGPUUsage);
            this.Controls.Add(this.comboBoxActivityMode);
            this.Controls.Add(this.labelGPUActivity);
            this.Controls.Add(this.richTextBoxGPU);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.chartGPUActivity);
            this.Controls.Add(this.labelGPUModel);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGPUActivity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelGPUModel;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartGPUActivity;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBoxGPU;
        private System.Windows.Forms.Label labelGPUActivity;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox comboBoxActivityMode;
        private System.Windows.Forms.Label labelGPUUsage;
    }
}

