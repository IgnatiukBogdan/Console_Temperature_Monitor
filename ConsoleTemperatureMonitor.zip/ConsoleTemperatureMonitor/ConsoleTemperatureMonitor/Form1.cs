﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using OpenHardwareMonitor.Hardware;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Forms.VisualStyles;

namespace ConsoleTemperatureMonitor
{
    public partial class Form1 : Form
    {
        private Computer computer;

        public Form1()
        {
            InitializeComponent();
            InitializeComputer();
            InitializeChart();
            InitializeCustomComboBox();

            timer1.Start(); // Убедитесь, что таймер запущен
            label1.Visible = false; // Начально скрываем лейбл
            
            // Встановлення кольорів для RichTextBox
            richTextBoxGPU.BackColor = Color.FromArgb(94, 94, 94); // Фоновий колір
            richTextBoxGPU.ForeColor = Color.Cyan; // Колір тексту
            // Встановлення шрифту для RichTextBox
            richTextBoxGPU.Font = new Font("Exo 2 ", 16);

            richTextBoxGPU.ReadOnly = true; // Відключення можливості введення тексту
            richTextBoxGPU.ScrollBars = RichTextBoxScrollBars.None; // Вимикаємо панель прокрутки
            richTextBoxGPU.BorderStyle = BorderStyle.None;
            // richTextBoxGPU.Enabled = false; // Вимкнення можливості редагування тексту


            this.FormBorderStyle = FormBorderStyle.FixedSingle; // Заборона зміни розміру форми
            this.MaximizeBox = false; // Заборона максимізації форми

            // Встановлення кольорів форми
            this.BackColor = Color.FromArgb(64, 64, 64);
            this.ForeColor = Color.White;

            // Додавання іконки для форми
            this.Icon = Properties.Resources.network_monitoring;


            // Встановлення назви форми
            this.Text = "Oculi";

            // Встановлення розміру форми
            this.Size = new Size(760, 380);

            // Центрування форми на екрані
            this.StartPosition = FormStartPosition.CenterScreen;

            // Вимкнення ресайзу форми
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // Вимкнення кнопки максимізації
            this.MaximizeBox = false;

            // Вимкнення кнопки згортання
            this.MinimizeBox = false;

            // Додавання події для закриття форми
            this.FormClosing += MainForm_FormClosing;

            // Установить начальную позицию формы
            this.StartPosition = FormStartPosition.Manual;

            // Установить координаты левого верхнего угла формы
            this.Location = new Point(0, 0);
        }

        private void InitializeCustomComboBox()
        {
            // Инициализация комбобокса
            comboBoxActivityMode.Items.AddRange(new string[] { "Одно ядро", "Несколько ядер" });
            comboBoxActivityMode.SelectedIndex = 0; // Устанавливаем первый элемент в качестве выбранного по умолчанию

            comboBoxActivityMode.Size = new Size(110, 30);
            comboBoxActivityMode.Location = new System.Drawing.Point(18, 174); // Устанавливаем позицию комбобокса на форме
            comboBoxActivityMode.DropDownStyle = ComboBoxStyle.DropDownList; // Устанавливаем стиль выпадающего списка
            comboBoxActivityMode.BackColor = Color.FromArgb(94, 94, 94); ;   // Задать тёмно серый задний цвет для комбобокса
            comboBoxActivityMode.ForeColor = Color.Cyan;   // Задать синий цвет текста для комбобокса
            comboBoxActivityMode.Font = new Font("Exo2", 10, FontStyle.Italic);
            this.Controls.Add(comboBoxActivityMode); // Добавляем комбобокс на форму
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Додавання логіки для закриття програми або очищення ресурсів
            DialogResult result = MessageBox.Show("Ви впевнені, що хочете закрити програму?", "Підтвердження закриття", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No)
            {
                e.Cancel = true; // Скасувати закриття форми
            }
            else
            {
                // Очистка ресурсів або інші дії перед закриттям
                // Наприклад, зупинка таймера або звільнення пам'яті
                timer1.Stop();
                computer.Close();
            }
        }

        private void InitializeComputer()
        {
            computer = new Computer();
            computer.Open();
            computer.GPUEnabled = true;

            timer1.Interval = 500; // Оновлення кожну секунду
            timer1.Tick += Timer1_Tick;
            timer1.Start();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            UpdateTemperature();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                label1.BackColor = Color.FromArgb(94, 94, 94);
                label1.ForeColor = Color.Aqua;
                label1.Text = "Вкл";
                label1.Visible = true; // Если чекбокс отмечен, показываем лейбл
                this.TopMost = true; // Встановлення форми поверх інших вікон
            }
            else
            {
                label1.Visible = false; // Если чекбокс снят, скрываем лейбл
                this.TopMost = false; // Встановлення форми в норму відносно інших вікон
            }
        }


        private void InitializeChart()
        {
            // Создаем новую серию для графика
            Series gpuLoadSeries = new Series("GPU Load");

            // Устанавливаем тип графика (линия)
            gpuLoadSeries.ChartType = SeriesChartType.Line;

            // Устанавливаем цвет линии
            gpuLoadSeries.Color = Color.Aqua;

            // Добавляем серию в коллекцию серий объекта Chart
            chartGPUActivity.Series.Add(gpuLoadSeries);

            chartGPUActivity.ChartAreas[0].AxisX.Minimum = 0; // Мінімальне значення на вісі X
            chartGPUActivity.ChartAreas[0].AxisX.Maximum = 50; // Максимальне значення на вісі X

            chartGPUActivity.ChartAreas[0].AxisY.Minimum = 0; // Мінімальне значення на вісі Y
            chartGPUActivity.ChartAreas[0].AxisY.Maximum = 100; // Максимальне значення на вісі Y

            timer1.Interval = 1000; // Оновлення кожну секунду

            chartGPUActivity.BackColor = Color.FromArgb(64, 64, 64);
            chartGPUActivity.ChartAreas[0].BackColor = Color.FromArgb(94, 94, 94);

            // Удаление меток числовых значений оси X
            chartGPUActivity.ChartAreas[0].AxisX.LabelStyle.Enabled = false;
            // Удаление меток числовых значений оси Y
            chartGPUActivity.ChartAreas[0].AxisY.LabelStyle.Enabled = false;

            // Устанавливаем количество делений на оси X и Y
            chartGPUActivity.ChartAreas[0].AxisX.Interval = 5;
            chartGPUActivity.ChartAreas[0].AxisY.Interval = 5;

            // Устанавливаем стиль сетки
            chartGPUActivity.ChartAreas[0].AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dot;
            chartGPUActivity.ChartAreas[0].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dot;

            // Устанавливаем цвет сетки
            chartGPUActivity.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.Black;
            chartGPUActivity.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.Black;
            // Очищаем легенду
            chartGPUActivity.Legends.Clear();
        }


        private void UpdateChart(double gpuLoad)
        {
            // Удаление самой левой точки, если количество точек превысило 50
            if (chartGPUActivity.Series["GPU Load"].Points.Count > 51)
            {
                chartGPUActivity.Series["GPU Load"].Points.RemoveAt(0);
            }
        }

        private void UpdateTemperature()
        {
            richTextBoxGPU.Clear(); // Очищаем RichTextBox для температур перед обновлением
            labelGPUModel.Text = ""; // Очищаем Label для модели перед обновлением

            bool gpuFound = false; // Переменная для отслеживания обнаружения дискретной видеокарты

            foreach (var hardwareItem in computer.Hardware)
            {
                hardwareItem.Update();

                if (hardwareItem.HardwareType == HardwareType.GpuNvidia || hardwareItem.HardwareType == HardwareType.GpuAti)
                {
                    gpuFound = true; // Дискретная видеокарта обнаружена

                    foreach (var sensor in hardwareItem.Sensors)
                    {
                        if (sensor.SensorType == SensorType.Temperature && sensor.Value.HasValue)
                        {
                            richTextBoxGPU.AppendText($"{sensor.Name} : {sensor.Value} °C\n");
                        }
                    }
                    // Выводим модель видеокарты в Label
                    labelGPUModel.BackColor = Color.FromArgb(94, 94, 94);
                    labelGPUModel.ForeColor = Color.Aqua;
                    labelGPUModel.Text = $"Model: {hardwareItem.Name}";

                    // Получаем данные о загрузке GPU
                    var activitySensor = hardwareItem.Sensors.FirstOrDefault(s => s.SensorType == SensorType.Load && s.Name == "GPU Core");
                    if (activitySensor != null && activitySensor.Value.HasValue)
                    {
                        // Получаем текущую активность GPU
                        double gpuLoad = activitySensor.Value.Value;

                        // Выводим процент активности на экран
                        labelGPUActivity.ForeColor = Color.Cyan;
                        labelGPUActivity.BackColor = Color.FromArgb(94, 94, 94);
                        labelGPUActivity.Text = $"GPU Activity: {gpuLoad}%";

                        // Проверяем, существует ли серия данных "GPU Load"
                        if (!chartGPUActivity.Series.Any(s => s.Name == "GPU Load"))
                        {
                            // Если серия данных не существует, создаем ее
                            InitializeChart();
                        }

                        // Добавляем новую точку на график
                        chartGPUActivity.Series["GPU Load"].Points.AddY(gpuLoad);

                        // Обновляем график
                        UpdateChart(gpuLoad);
                    }
                }
            }

            // Если дискретная видеокарта не обнаружена, выведем информацию о встроенной
            if (!gpuFound)
            {
                richTextBoxGPU.AppendText("Встроенная видеокарта: \n");

                // Подключаем библиотеку OpenHardwareMonitor для мониторинга
                Computer computer = new Computer();
                computer.Open();
                computer.GPUEnabled = true;

                // Проверяем каждое устройство на наличие датчиков температуры GPU
                foreach (var hardwareItem in computer.Hardware)
                {
                    hardwareItem.Update();

                    foreach (var sensor in hardwareItem.Sensors)
                    {
                        if (sensor.SensorType == SensorType.Temperature && sensor.Value.HasValue)
                        {
                            // Если датчики температуры GPU найдены, считаем это видеокартой
                            richTextBoxGPU.AppendText($"{sensor.Name} : {sensor.Value} °C\n");

                            // Выводим модель видеокарты в Label
                            labelGPUModel.BackColor = Color.FromArgb(94, 94, 94);
                            labelGPUModel.ForeColor = Color.Aqua;
                            labelGPUModel.Text = $"Model: {hardwareItem.Name}";

                            gpuFound = true;
                            break;
                        }
                    }

                    if (gpuFound)
                    {
                        break;
                    }
                }
            }
        }

        private void comboBoxActivityMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxActivityMode.SelectedItem != null)
            {
                string selectedMode = comboBoxActivityMode.SelectedItem.ToString();

                // Очистка предыдущих значений
                chartGPUActivity.Series["GPU Load"].Points.Clear();

                // Обработка выбранного режима
                if (selectedMode == "Одно ядро")
                {
                    CalculateSingleCoreActivity();
                }
                else if (selectedMode == "Несколько ядер")
                {
                    CalculateMultiCoreActivity();
                }

                // Устанавливаем цвет текста
                labelGPUUsage.ForeColor = Color.Cyan;
                labelGPUUsage.BackColor = Color.FromArgb(94, 94, 94);
                labelGPUUsage.BorderStyle = BorderStyle.FixedSingle; // Установка стиля рамки

                // Устанавливаем текст для labelGPUUsage
                labelGPUUsage.Text = "Режим: " + selectedMode;

                // Снимаем выделение текста
                comboBoxActivityMode.SelectedIndex = -1;
            }
        }

        private void CalculateSingleCoreActivity()
        {
            // Очищаем график от предыдущих значений
            chartGPUActivity.Series["GPU Load"].Points.Clear();

            // Пример вычисления активности для одного ядра (заглушка)
            Random random = new Random();
            for (int i = 0; i < 50; i++)
            {
                double gpuLoad = random.Next(0, 0); // Генерация случайного значения от 0 до 100 для активности
                chartGPUActivity.Series["GPU Load"].Points.AddY(gpuLoad); // Добавляем полученное значение на график
            }
        }

        private void CalculateMultiCoreActivity()
        {
            // Очищаем график от предыдущих значений
            chartGPUActivity.Series.Clear();

            // Получаем количество ядер видеокарты
            int coreCount = GetGPUCoreCount(); // Предположим, что у вас есть функция GetGPUCoreCount(), которая возвращает количество ядер

            // Создаем отдельные серии для каждого ядра и добавляем их на график
            for (int core = 0; core < coreCount; core++)
            {
                Series coreSeries = new Series($"GPU Load Core {core + 1}");
                coreSeries.ChartType = SeriesChartType.Line;
                chartGPUActivity.Series.Add(coreSeries);
            }

            // Пример вычисления активности для нескольких ядер (заглушка)
            Random random = new Random();
            for (int core = 0; core < coreCount; core++)
            {
                for (int i = 0; i < 50; i++)
                {
                    double gpuLoad = random.Next(0, 0); // Генерация случайного значения от 0 до 100 для активности
                    chartGPUActivity.Series[$"GPU Load Core {core + 1}"].Points.AddY(gpuLoad); // Добавляем полученное значение на график
                }
            }
        }

        // Функция для определения количества ядер видеокарты
        private int GetGPUCoreCount()
        {
            // Здесь можно реализовать логику определения количества ядер
            // Например, использовать API для получения информации о видеокарте
            // или использовать сторонние библиотеки, такие как OpenHardwareMonitor
            // Для примера вернем случайное значение от 1 до 8
            Random random = new Random();
            return random.Next(1, 9);
        }

    }
}